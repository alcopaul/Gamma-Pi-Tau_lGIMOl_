﻿Option Strict On
Option Explicit On
Option Infer On
Option Compare Text

Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        TextBox2.Text = x(TextBox1.Text, TextBox3.Text)
    End Sub
    Private Function x(sText As String, ekey As String) As String
        On Error Resume Next
        Dim i As Integer, shash As Integer, crbyte As Char, g As Integer, tkey As Integer, xx As String
        tkey = CInt(ekey)
        g = Len(sText)
        xx = ""
        For i = 1 To g
            shash = Asc(Mid(sText, i, 1))
            crbyte = Chr(shash Xor (tkey Mod 256)) 'tkey = 255 max -> tkey mod 256 ->>>>
            xx += crbyte.ToString
        Next i
        Return xx
    End Function
End Class
